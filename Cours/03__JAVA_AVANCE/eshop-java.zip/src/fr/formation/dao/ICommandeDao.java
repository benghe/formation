package fr.formation.dao;

import fr.formation.model.Commande;

public interface ICommandeDao extends IDao<Commande> {

}