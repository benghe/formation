package fr.formation.dao;

import fr.formation.model.Produit;

public interface IProduitDao extends IDao<Produit> {

}