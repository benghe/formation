package fr.formation.model;

public enum PersonneType {
	CLIENT, FOURNISSEUR;
}