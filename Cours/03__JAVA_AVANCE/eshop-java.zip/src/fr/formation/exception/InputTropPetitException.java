package fr.formation.exception;

public class InputTropPetitException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}