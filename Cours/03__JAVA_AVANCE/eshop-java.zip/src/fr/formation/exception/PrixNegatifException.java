package fr.formation.exception;

public class PrixNegatifException extends RuntimeException {

}