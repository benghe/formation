package fr.formation.exception;

public class LibelleVideException extends RuntimeException {
	
}