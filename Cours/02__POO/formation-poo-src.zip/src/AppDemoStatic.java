
public class AppDemoStatic {

}
