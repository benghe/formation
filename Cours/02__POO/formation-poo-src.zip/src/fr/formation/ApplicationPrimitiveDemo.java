package fr.formation;

public class ApplicationPrimitiveDemo {
	public static void main(String[] args) {
		Integer a = Integer.parseInt("75");
		
		for (Integer i = 0; i < 32; i++) {
			
		}
	}
}