package fr.formation.zoobug;

public class Canide extends Mammifere {

}