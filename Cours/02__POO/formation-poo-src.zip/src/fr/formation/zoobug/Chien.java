package fr.formation.zoobug;

public class Chien extends Canide {
	@Override
	public void manger() {
		System.out.println("Le chien mange ...");
	}
}