package fr.formation.zoobug;

public class Chat extends Felide {
	public Chat() {
		System.out.println("CREATION D'UN CHAT");
	}
	
	public void manger() {
		System.out.println("Le chat mange ...");
	}
}