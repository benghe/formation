package fr.formation.zoo;

public abstract class Canide extends Mammifere {

}