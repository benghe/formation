package fr.formation.zoo;

public class Chasseur {
	public void chasser() {
		System.out.println("Le chasseur chasse ...");
	}
}